using System;
using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using Newtonsoft.Json.Linq;

namespace HelloWorld {
   public class Test2 : IExternalCommand {
      public Result Execute(ExternalCommandData revit,
                            ref string message, ElementSet elements) {



         string js = @"

         {
              'ParentGuid': '16daadd7-0366-4739-a044-a736be12a6ea-007621df',
              'SelfGuid': '6efbef1d-de53-4dea-960b-c79a57a0c74b-0085bcd5',
              'SelfTypeId': 8054113,
              'TimeStamp': 1676966647.3828125
            }";



         JObject jsonObj = JObject.Parse(js);
         JToken parent = jsonObj["ParentGuid"];
         Console.WriteLine(parent.ToString());

         return Result.Succeeded;
      }
   }
}