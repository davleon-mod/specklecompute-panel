
from Autodesk.Revit import DB
import zero11h.revit_api.revit_utils as mru

uiapp = __revit__
uidoc = uiapp.ActiveUIDocument
app = uiapp.Application
doc = uidoc.Document


# Component guid (from layergroup metadata)

comp = doc.GetElement("6efbef1d-de53-4dea-960b-c79a57a0c74b-0085bc63")

# Perforator guid (from layergroup metadata)

perf = doc.GetElement("6efbef1d-de53-4dea-960b-c79a57a0c74b-0085bdb3")



# We extract face from perforator on direction of extrusion from reference side of component

solid = mru.RvtSolidUtils.get_all_solids_from_instance(perf, view_detail=DB.ViewDetailLevel.Coarse)[0]
print solid

face = mru.RvtSolidUtils.get_solid_face_from_normal(solid, perf.FacingOrientation.Negate())

# We grab first loop and convert to curve

res = []

for edge in face.EdgeLoops.Item[0]:
    res.append(edge.AsCurve())



print res