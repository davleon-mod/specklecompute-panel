import os, sys, clr
from Autodesk.Revit import DB


clr.AddReferenceToFileAndPath(r'C:\Users\David\AppData\Roaming\Autodesk\Revit\Addins\2022\SpeckleRevit2\SpeckleCore2') #SpeckleCore2
clr.AddReferenceToFileAndPath(r'C:\Users\David\AppData\Roaming\Speckle\Kits\Objects\Objects.Converter.Revit2022') #Revit Objects
clr.AddReferenceToFileAndPath(r'C:\Program Files\Autodesk\Revit 2022\RevitAPI') #RevitAPI
clr.AddReferenceToFileAndPath(r'C:\Users\David\AppData\Roaming\Speckle\Kits\Objects\Objects') #Speckle Objects
clr.AddReferenceToFileAndPath(r'C:\Windows\Microsoft.NET\assembly\GAC_MSIL\netstandard\v4.0_2.0.0.0__cc7b13ffcd2ddd51\netstandard.dll' ) #netstandard


# import Speckle as spk
# import Objects as spkobj

# doc = __revit__.ActiveUIDocument.Document
# lg = doc.GetElement(DB.ElementId(89213))
# kit = spk.Core.Kits.KitManager.GetDefaultKit()
# converter = kit.LoadConverter(spkobj.Converter.Revit.ConverterRevit.RevitAppName)
# converter.SetContextDocument(doc)
# cvr = converter.ConvertToSpeckle(lg)
# print(cvr)


# using System;
# using Speckle.Core.Credentials;
# using Speckle.Core.Api;
# using System.Threading;
# using System.Collections.Generic;
# using Speckle.Core.Transports;


from Speckle.Core import Credentials, Api, Transports
import time

streamId = "6766a6eaa3"
branchName = "main"



defaultAccount = Credentials.AccountManager.GetDefaultAccount()
client = Api.Client(defaultAccount)

branch = client.BranchGet(streamId, "main", 1) 
time.sleep(1)
print(branch)
branch = branch.Result
hash_ = branch.commits.items[0].referencedObject

transport = Transports.ServerTransport(defaultAccount, streamId)
receivedBase = Api.Operations.Receive(hash_, transport)
receivedBase = receivedBase.Result

newHash = Api.Operations.Send(receivedBase)
newHash = newHash.Result

commit = Api.CommitCreateInput()

commit.branchName = branchName,
commit.message = "Created with Revit from IronPython."
commit.objectId = newHash,
commit.streamId = streamId,
commit.sourceApplication = "Revit"

commitId = client.CommitCreate(commit)
time.sleep(1)

print(commitId)
commitId = commitId.Result



