from specklepy.api.client import SpeckleClient

import requests
from requests.adapters import HTTPAdapter, Retry


session = requests.session()
adapter = HTTPAdapter(
    max_retries=Retry(
        total=3,
        backoff_factor=0.1,
        status_forcelist=[500, 502, 503, 504],
        allowed_methods=None,
    )
)
for prefix in "http://", "https://":
    session.mount(prefix, adapter)

response = session.post('https://speckle.xyz/graphql', json={'query': '{serverInfo{version}}'})
print(response.status_code)
print(response.text)