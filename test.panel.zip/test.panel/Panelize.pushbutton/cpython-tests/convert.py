clr.AddReferenceToFileAndPath(r'C:\Users\David\AppData\Roaming\Autodesk\Revit\Addins\2022\SpeckleRevit2\SpeckleCore2.dll')
clr.AddReferenceToFileAndPath(r'C:\Users\David\AppData\Roaming\Speckle\Kits\Objects\Objects.Converter.Revit2022.dll')
clr.AddReferenceToFileAndPath(r'C:\Users\David\AppData\Roaming\Speckle\Kits\Objects\Objects')

import Speckle as spk``
import Objects as spkobj
#import Speckle.Core.Models.Base as base
#import Objects.Converter.Revit as conv


lg = doc.GetElement(ElementId(10389213))

kit = spk.Core.Kits.KitManager.GetDefaultKit()
converter = kit.LoadConverter(spkobj.Converter.Revit.ConverterRevit.RevitAppName)
converter.SetContextDocument(doc)
cvr = converter.ConvertToSpeckle(lg)