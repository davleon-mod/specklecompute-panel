#! python3
from specklepy.api.client import SpeckleClient
from specklepy.api.credentials import get_default_account

from specklepy.objects import Base
from specklepy.objects.geometry import Point

from specklepy.transports.server import ServerTransport
from specklepy.api import operations


class Block(Base):
    length: float
    width: float
    height: float
    origin: Point = None

    def __init__(self, length=1.0, width=1.0, height=1.0, origin=Point(), **kwargs) -> None:
        super().__init__(**kwargs)
        # mark the origin as a detachable attribute
        self.add_detachable_attrs({"origin"})

        self.length = length
        self.width = width
        self.height = height
        self.origin = origin


#CLIENT   -------------
# # initialise the client
client = SpeckleClient(host="http://139.59.153.219/", use_ssl=False) # or whatever your host is

# AUTHENTICATE   -------------
# # authenticate the client with a token
account = get_default_account()
client.authenticate_with_account(account)

# authenticate with token
# client.authenticate_with_token("ae5d572e0de82c87de44787a7d9ed7a217e91ef61e")


# CREATE STREAM -------------
# create a new stream. this returns the stream id
new_stream_id = client.stream.create(name="a shiny new stream")

# use that stream id to get the stream from the server
new_stream = client.stream.get(id=new_stream_id)



# SEND  OBJ  -------------
# here's the data you want to send
block = Block(length=2, height=4)

# next create a server transport - this is the vehicle through which you will send and receive
transport = ServerTransport(client=client, stream_id=new_stream_id)
 
# this serialises the block and sends it to the transport
hash = operations.send(base=block, transports=[transport])

# you can now create a commit on your stream with this object
commid_id = client.commit.create(
    stream_id=new_stream_id, 
    object_id=hash, 
    message="this is a block I made in speckle-py",
    )