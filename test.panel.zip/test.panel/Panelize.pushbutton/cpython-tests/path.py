import os, sys, clr, System

SpeckleCore2 = (r'C:\Users\David\AppData\Roaming\Autodesk\Revit\Addins\2022\SpeckleRevit2\SpeckleCore2')
SpeckleObjects = (r'C:\Users\David\AppData\Roaming\Speckle\Kits\Objects\Objects.Converter.Revit2022')
RevitAPI = (r'C:\Program Files\Autodesk\Revit 2022\RevitAPI')
clr.AddReference(r'C:\Users\David\AppData\Roaming\Speckle\Kits\Objects\Objects')

clr.AddReference(SpeckleCore2)
clr.AddReference(RevitAPI)
clr.AddReference(SpeckleObjects)

dll_ref = clr.AddReference(SpeckleObjects)
# print (globals())
# print(dll_ref.ExportedTypes)


import Speckle as spk
import Objects as spkobj


# lg = doc.GetElement(ElementId(10389213))

kit = spk.Core.Kits.KitManager.GetDefaultKit()
converter = kit.LoadConverter(spkobj.Converter.Revit.ConverterRevit.RevitAppName)
# converter.SetContextDocument(doc)
# cvr = converter.ConvertToSpeckle(lg)





