import specklepy
from specklepy.api.client import SpeckleClient
from specklepy.api.credentials import get_local_accounts

query = ""
speckle_accounts = get_local_accounts()
print(speckle_accounts )
for i, acc in enumerate(speckle_accounts):
    try:
        speckle_client = SpeckleClient(acc.serverInfo.url, acc.serverInfo.url.startswith("https"))
        print(speckle_client)
        speckle_client.authenticate_with_token(token=acc.token)
        print(speckle_client)
        results = speckle_client.stream.search(query)
        print(results)
    except Exception as e: 
        print(str(e))

print("done")