#! python3
import os, sys, clr

SpeckleCore2 = (r'C:\Users\David\AppData\Roaming\Autodesk\Revit\Addins\2022\SpeckleRevit2\SpeckleCore2')
SpeckleObjects = (r'C:\Users\David\AppData\Roaming\Speckle\Kits\Objects\Objects.Converter.Revit2022')
RevitAPI = (r'C:\Program Files\Autodesk\Revit 2022\RevitAPI')
clr.AddReference(r'C:\Users\David\AppData\Roaming\Speckle\Kits\Objects\Objects')

clr.AddReference(SpeckleCore2)
clr.AddReference(RevitAPI)
clr.AddReference(SpeckleObjects)

dll_ref = clr.AddReference(SpeckleObjects)

import Speckle as spk
import Objects as spkobj
from Autodesk.Revit import DB

from specklepy.api.client import SpeckleClient
from specklepy.api.credentials import get_default_account

from specklepy.transports.server import ServerTransport
from specklepy.api import operations


# doc = __revit__.ActiveUIDocument.Document

# lg = doc.GetElement(DB.ElementId(10389213))

# kit = spk.Core.Kits.KitManager.GetDefaultKit()
# converter = kit.LoadConverter(spkobj.Converter.Revit.ConverterRevit.RevitAppName)
# converter.SetContextDocument(doc)
# block = converter.ConvertToSpeckle(lg)




#CLIENT   -------------
# # initialise the client
client = SpeckleClient(host="http://139.59.153.219/", use_ssl=False) # or whatever your host is



# AUTHENTICATE   -------------
# # authenticate the client with a token
account = get_default_account()
client.authenticate_with_account(account)

print(client)

# authenticate with token




# # CREATE STREAM -------------
# # create a new stream. this returns the stream id
# new_stream_id = client.stream.create(name="another stream")

# # use that stream id to get the stream from the server
# new_stream = client.stream.get(id=new_stream_id)



# # SEND  OBJ  -------------
# # here's the data you want to send

# # next create a server transport - this is the vehicle through which you will send and receive
# transport = ServerTransport(client=client, stream_id=new_stream_id)
 
# # this serialises the block and sends it to the transport
# hash = operations.send(base=block, transports=[transport])

# # you can now create a commit on your stream with this object
# commid_id = client.commit.create(
#     stream_id=new_stream_id, 
#     object_id=hash, 
#     message="this is a panel I made in speckle-py",
#     )


