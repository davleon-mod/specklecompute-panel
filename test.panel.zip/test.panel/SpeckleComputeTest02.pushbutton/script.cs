using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
// using System.Windows.Forms;

using Autodesk.Revit.UI;
using Autodesk.Revit.DB;

using Speckle.Core.Credentials;
using Speckle.Core.Api;
using Speckle.Core.Transports;
using Objects;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

using SpeckleCompute;

namespace HelloWorld {
   public class Test2 : IExternalCommand {

      public Result Execute(ExternalCommandData revit,
                            ref string message, ElementSet elements) {

            
            var sc = new Compute();
            sc.Run(revit)  ;             
            

            return Result.Succeeded;
      }
   }
}